#ifndef GAME_H
#define GAME_H
//#include "globals.h"
//#include "Arena.h"
#include "Player.h"
#include <iostream>
#include <string>
using namespace std;

class Arena;

class Game
{
public:
    // Constructor/destructor
    Game(int rows, int cols, int nVampires);
    ~Game();

    // Mutators
    void play();

private:
    Arena* m_arena;

    // Helper functions
    string takePlayerTurn();
};

#endif