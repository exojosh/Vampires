#include "History.h"
History::History(int nRows, int nCols)
{
	m_rows = nRows;
	m_cols = nCols;
    for (int r = 1; r <= nRows; r++)
        for (int c = 1; c <= nCols; c++)
            m_grid[r-1][c-1] = 64;
}

bool History::record(int r, int c) //Gets called when a vampire is alive on a poisoned square
{
    if (r >= 1 && r <= m_rows && c >= 1 && c <= m_cols)
    {
        m_grid[r-1][c-1]++;
        return true;
    }
    return false;
}

void History::display() const
{
    clearScreen();
    for (int r = 1; r <= m_rows; r++)
    {
        for (int c = 1; c <= m_cols; c++)
            if (m_grid[r - 1][c - 1] == 64)
                std::cout << ".";
            else if (m_grid[r - 1][c - 1] >= 90)
                std::cout << "Z";
            else
                std::cout << m_grid[r - 1][c - 1];
        std::cout << std::endl;
    }   
    std::cout << "\n";
}
	